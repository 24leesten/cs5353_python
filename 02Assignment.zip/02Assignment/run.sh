echo ''
echo '----------------------'
echo '| ASSIGNMENT 02      |'
echo '|	  Leland Stenquist |'
echo '|	  U0634909         |'
echo '----------------------'
echo ''
python 01_Experiment.py
python 02_Experiment.py
python 03_Experiment.py
