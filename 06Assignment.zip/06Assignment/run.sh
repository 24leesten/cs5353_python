#!/bin/sh
echo "================================="
echo "========= ASSIGNMENT 6 =========="
echo "================================="
echo ""

python driver.py